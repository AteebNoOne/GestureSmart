export interface User {
    firstName: string;
    lastName: string;
    email: string;
    dateOfBirth: string;
    age: string;
    phone: string;
    location: string;
    createdAt: string;
}