export const defaultUser = {
    firstName: "",
    lastName: "",
    email: "",
    dateOfBirth: "",
    age: "",
    phone: "",
    location: "",
    createdAt: ""
}